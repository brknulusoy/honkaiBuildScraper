- Run the main.exe to start the program
- Enter character name
- There is an excel spredsheet called 'light_cones'. Edit it to the light cones you have
- If you want to get another blank lightcone sheet for some reason click the get lightcone sheet button
- After making changes on your sheet you do not need to restart the program just press update

- All lightcones and relics are in order of best in slot to least best

- In relics the numbers show which order they are preffered
- If there are no numbers next to the relic, that shows the set is 2 piece with the previous set

